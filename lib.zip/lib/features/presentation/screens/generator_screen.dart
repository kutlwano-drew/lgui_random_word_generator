import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart'; 
import 'package:flutter_glow/flutter_glow.dart'; // Added for the glow text components
import '../widgets/app_bar/desktop_app_bar.dart';
import '../widgets/background/aura_background.dart';
import '../widgets/controls/control_row.dart';
import '../widgets/overlay/countdown_overlay.dart';

class GeneratorScreen extends StatefulWidget {
  const GeneratorScreen({super.key});

  @override
  State<GeneratorScreen> createState() => _GeneratorScreenState();
}

class _GeneratorScreenState extends State<GeneratorScreen> {
  final Random _random = Random();

  String _generatedWord = "";
  String _categoryLabel = "";
  Timer? _generationTimer;

  bool _isAutoGenerating = false;
  bool _showCountdown = false;
  int _timerInterval = 3; 
  int _currentCountdown = 3; // Tracks the active real-time countdown ticks

  @override
  void initState() {
    super.initState();
    _runGeneration(); // Generate first word on launch
  }

  /// Pulls a random word/pair from the package and identifies its category
  void _runGeneration() {
    setState(() {
      // 1. Roll a 3-sided die to decide what kind of word to generate
      final roll = _random.nextInt(3);

      if (roll == 0) {
        // Generate a classic Word Pair (Adjective + Noun)
        final pair = WordPair.random();
        _generatedWord = pair.asPascalCase;
        _categoryLabel = "CATEGORY: WORD PAIR (ADJ + NOUN)";
      } else if (roll == 1) {
        // Generate a single Noun
        final noun = nouns[_random.nextInt(nouns.length)];
        _generatedWord = noun[0].toUpperCase() + noun.substring(1);
        _categoryLabel = "CATEGORY: NOUN";
      } else {
        // Generate a single Adjective
        final adjective = adjectives[_random.nextInt(adjectives.length)];
        _generatedWord = adjective[0].toUpperCase() + adjective.substring(1);
        _categoryLabel = "CATEGORY: ADJECTIVE";
      }
    });
  }

  void _handleAutoToggle() {
    if (_isAutoGenerating) {
      _stopAutoGeneration();
    } else {
      setState(() {
        _showCountdown = true;
      });
    }
  }

  void _startAutoGeneration() {
    setState(() {
      _isAutoGenerating = true;
      _showCountdown = false;
      _currentCountdown = _timerInterval; // Initialize countdown frame
    });
    _runGeneration(); // Immediate fire
    
    // Ticks every 1 second to update the visual countdown properly
    _generationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _currentCountdown--;
        if (_currentCountdown <= 0) {
          _runGeneration();
          _currentCountdown = _timerInterval; // Reset back to the set interval loop
        }
      });
    });
  }

  void _stopAutoGeneration() {
    _generationTimer?.cancel();
    setState(() {
      _isAutoGenerating = false;
    });
  }

  @override
  void dispose() {
    _generationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DesktopAppBar(), 
      body: Stack(
        children: [
          // Canvas layer
          AuraBackground(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Inline conditional countdown header using flutter_glow layout
                    if (_isAutoGenerating) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const GlowText(
                            "next word in ",
                            style: TextStyle(color: Colors.white, fontSize: 16),
                            glowColor: Colors.white24,
                          ),
                          GlowText(
                            "$_currentCountdown",
                            style: const TextStyle(
                              color: Colors.redAccent,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            glowColor: Colors.redAccent,
                          ),
                          const GlowText(
                            " seconds",
                            style: TextStyle(color: Colors.white, fontSize: 16),
                            glowColor: Colors.white24,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Glassmorphic Output Window
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 56, vertical: 34),
                      margin: const EdgeInsets.only(bottom: 40),
                      decoration: BoxDecoration(
                        color: const Color(0xFF101016),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white.withOpacity(0.08)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.deepPurple.withOpacity(0.12),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 250),
                            transitionBuilder: (child, animation) => ScaleTransition(
                              scale: animation,
                              child: child,
                            ),
                            child: Text(
                              _generatedWord,
                              key: ValueKey<String>(_generatedWord),
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 44,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          // The package-derived category label
                          Text(
                            _categoryLabel,
                            style: const TextStyle(
                              color: Colors.white38,
                              fontSize: 10,
                              fontFamily: 'monospace',
                              letterSpacing: 2.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Controls layout
                    ControlRow(
                      onGenerate: _runGeneration,
                      isAutoGenerating: _isAutoGenerating,
                      onToggleAutoGenerate: _handleAutoToggle,
                      timerDuration: _timerInterval,
                      onTimerChanged: (val) {
                        setState(() {
                          _timerInterval = val;
                          if (_isAutoGenerating) {
                            _currentCountdown = val; // Synchronize ticker ceiling safely on step changes
                          }
                        });
                        if (_isAutoGenerating) {
                          _stopAutoGeneration();
                          _startAutoGeneration();
                        }
                      },
                    ),

                    // Modifier button layer commented out until audio architecture/tones are complete
                    // const SizedBox(height: 20),
                    // GestureDetector(
                    //   onTap: () {
                    //     showDialog(
                    //       context: context,
                    //       builder: (context) => const SoundSettingsDialog(),
                    //     );
                    //   },
                    //   child: const ModifierButtonWidget(),
                    // ),
                  ],
                ),
              ),
            ),
          ),

          // Modal 3-2-1 delay overlay layer
          if (_showCountdown)
            CountdownOverlay(
              count: 3,
              onFinished: _startAutoGeneration,
            ),
        ],
      ),
    );
  }
}